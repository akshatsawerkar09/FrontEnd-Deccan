import { Component, OnInit } from '@angular/core';
import { IUser } from 'src/app/utility/IUser';
import { NotificationService } from 'src/app/utility/notification.service';

@Component({
  selector: 'app-side-nav',
  templateUrl: './side-nav.component.html',
  styleUrls: ['./side-nav.component.scss']
})
export class SideNavComponent implements OnInit {

  constructor(private _notificationService : NotificationService) { }

  user!: IUser;

  ngOnInit(): void {
    this.user = JSON.parse(sessionStorage['user']);
    console.log(this.user);
    this._notificationService.sendNotification(this.user);
  }

}
