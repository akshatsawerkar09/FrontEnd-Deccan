import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { concat } from 'rxjs';
import { IUser } from 'src/app/utility/IUser';
import { LoginService } from 'src/app/utility/login.service';
import { NotificationService } from 'src/app/utility/notification.service';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.scss']
})
export class ChangePasswordComponent implements OnInit {

  userNotFound : string = "";

  hide = true;

  checkUser!: IUser;

  newPassword!: string;

  user!: IUser;

  constructor(private _loginService : LoginService , private _router : Router , private _notificationService : NotificationService) { }

  ngOnInit(): void {
    this.user = JSON.parse(sessionStorage['user']);
    console.log(this.user);
    this._notificationService.sendNotification(this.user);
    this.user = JSON.parse(sessionStorage['user']);
    console.log(this.user);
  }

  changePasswordForm= new FormGroup({
    userName : new FormControl('',[Validators.required]) ,
    password : new FormControl('',[Validators.required]) ,
    newPassword : new FormControl('',[Validators.required])
  });

  changePassword(changePasswordForm : FormGroup)
  {
      this.checkUser = this.changePasswordForm.value;
      console.log(this.checkUser);
      this.newPassword =  this.changePasswordForm.controls['newPassword'].value;

      this._loginService.changePassword(this.checkUser , this.newPassword).subscribe(
        data =>  {
          console.log(data);
          this.user =  data;
          if(this.user == null)
          {
              this.userNotFound = "Invalid Credentials";
          }
          else
          {
            sessionStorage['user' ] = JSON.stringify( this.user );
          }
        }
      )

      this._router.navigateByUrl('/userDashboard');
  }

}
