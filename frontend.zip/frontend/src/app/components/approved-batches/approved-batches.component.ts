import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { EnrolledSportsService } from 'src/app/utility/enrolled-sports.service';
import { IEnrolledSports } from 'src/app/utility/IEnrolledSports';
import { IUser } from 'src/app/utility/IUser';
import { NotificationService } from 'src/app/utility/notification.service';
import { TableUtil } from 'src/app/utility/tableUtil';
//import { MatTableExporterModule } from 'mat-table-exporter';

@Component({
  selector: 'app-approved-batches',
  templateUrl: './approved-batches.component.html',
  styleUrls: ['./approved-batches.component.scss']
})
export class ApprovedBatchesComponent implements OnInit {

  user!: IUser;

  approvedBatches!: IEnrolledSports[];

  constructor(private _enrollService : EnrolledSportsService , private _router : Router , private _notificationService : NotificationService) { 

    
  }



  displayedColumns = ['sportsName','batchName','coachName' , 'startTime' , 'endTime' ,  'managerName' , 'payNow'];
  dataSource!: MatTableDataSource<any>;
    
  arrayObj : any [] = [];

  obj : any;

  @ViewChild('paginator') paginator! : MatPaginator; 
  @ViewChild(MatSort) matSort! : MatSort;


  ngOnInit(): void {
    this.user = JSON.parse(sessionStorage['user']);
    console.log(this.user);
    this._notificationService.sendNotification(this.user);
    this.arrayObj = [];
    this.user = JSON.parse(sessionStorage['user']);

//    this._enrollService.getEnrolledListByUser(this.user.userId).subscribe(
//      data => {
 //       console.log(data);
//        this.approvedBatches = data;
//      }
//    )
//    ,'batchName','coachName' , 'startTime' , 'endTime' ,  'managerName' , 'payNow'

    this._enrollService.getApprovedListByUser(this.user.userId).subscribe(
        data => {
          console.log(data);
          this.approvedBatches = data;

          for(var batch of this.approvedBatches)
          {
              this.obj= {
                sportsName : batch.sportsId.sportsName ,
                batchName : batch.batchId.batchName , 
                coachName : batch.batchId.coachName ,
                startTime : batch.batchId.startTime ,
                endTime : batch.batchId.endTime ,
                managerName :  batch.sportsId.managerId.userName ,
                paymentStatus : batch.paymentStatus ,
                enrolledId : batch.enrolledId
              }

              this.arrayObj.push(this.obj);
          }

          console.log(this.arrayObj);

          this.dataSource = new MatTableDataSource(this.arrayObj);
          console.log(this.dataSource);
          this.dataSource.paginator = this.paginator;
         this.dataSource.sort = this.matSort;
        }
     )

  }


 /* filterData(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  */


/* payment(enrolledId : number)
  {
    console.log(enrolledId);
    this._enrollService.payment(enrolledId).subscribe(
      data =>  {
        console.log("payment done");
      }
    )
   // window.location.reload();
   this.ngOnInit();
  }
*/

filterData($event : any){
  console.log($event.target.value);
  this.dataSource.filter = $event.target.value;
  console.log(this.dataSource.filter);
}


exportTable(){
  TableUtil.exportToPdf("ExampleTable");
}


  payment(enrolledId : any)
  {
    console.log(enrolledId);
    this._router.navigate(['/payment/'+enrolledId]);
  }
}
