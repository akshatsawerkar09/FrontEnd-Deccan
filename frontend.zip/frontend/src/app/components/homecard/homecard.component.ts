import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homecard',
  templateUrl: './homecard.component.html',
  styleUrls: ['./homecard.component.scss']
})
export class HomecardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
