import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { NotificationService } from 'src/app/utility/notification.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit {

  user : any ={
    userRole : "",
  }

  subscription : Subscription = new Subscription;

  constructor(private _notificationService : NotificationService) { }

  ngOnInit(): void {
     // sessionStorage.setItem( "user" , this.user );

     //sessionStorage['user' ] = JSON.stringify( this.user );

     this.user = JSON.parse(sessionStorage['user']);
    /* this.subscription = this._notificationService.getNotification().subscribe(
       data=> {
         this.user = data;
         console.log(this.user);
       }
     )
       */
  }

  
}
