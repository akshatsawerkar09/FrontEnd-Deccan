import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ILike } from './ILike';

@Injectable({
  providedIn: 'root'
})
export class LikeService {

  constructor(private _http :  HttpClient) { }

  baseUrl : string = "http://localhost:8080/user";

  

  addLike(comment : ILike) : Observable<ILike>{
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json'}) };
    return this._http.post<ILike>(this.baseUrl + '/addLike/',
    comment, httpOptions);
  }

  removeLike(comment : ILike) : Observable<ILike>{
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json'}) };
    return this._http.post<ILike>(this.baseUrl + '/removeLike/',
    comment, httpOptions);
  }
  
  getAllUserLikes(userId : number) : Observable<ILike[]>{
    return this._http.get<ILike[]>(this.baseUrl + '/getAllUserLikes/' + userId);
  }

  getAllSportsLikes(sportsId : number) : Observable<ILike[]>{
    return this._http.get<ILike[]>("http://localhost:8080/manager" + '/getAllSportsLikes/' + sportsId);
  }

  getAllLikes() : Observable<ILike[]>{
    return this._http.get<ILike[]>("http://localhost:8080/admin" + '/getAllLikes' );
  }
}
