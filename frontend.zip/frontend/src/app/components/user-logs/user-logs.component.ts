import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { EnrolledSportsService } from 'src/app/utility/enrolled-sports.service';
import { IEnrolledSports } from 'src/app/utility/IEnrolledSports';
import { IUser } from 'src/app/utility/IUser';
import { NotificationService } from 'src/app/utility/notification.service';
import { TableUtil } from 'src/app/utility/tableUtil';

@Component({
  selector: 'app-user-logs',
  templateUrl: './user-logs.component.html',
  styleUrls: ['./user-logs.component.scss']
})
export class UserLogsComponent implements OnInit {

  user!: IUser;

  enrolledSports!: IEnrolledSports[];

  displayedColumns = ['userName','sportsName','batchName' , 'coachName' , 'startTime' ,  'endTime' , 'fees' , 'managerName',  'enrolledStatus'  , 'paymentStatus' , 'timestamp' ];
  dataSource!: MatTableDataSource<any>;
    
  arrayObj : any [] = [];

  obj : any;

  @ViewChild('paginator') paginator! : MatPaginator; 
  @ViewChild(MatSort) matSort! : MatSort;

  constructor(private _enrolledService :  EnrolledSportsService , private _notificationService : NotificationService) { }

  ngOnInit(): void {
    this.user = JSON.parse(sessionStorage['user']);
    console.log(this.user);
    this._notificationService.sendNotification(this.user);
    this.arrayObj = [];
    this.user = JSON.parse(sessionStorage['user']);
    this._enrolledService.getAllEnrolledSports().subscribe(
      data => {
        console.log(data);
        this.enrolledSports = data;
        console.log(this.enrolledSports);
            for(var request of this.enrolledSports)
            {
                this.obj= {
                  userName : request.userId.userName ,
                  sportsName : request.sportsId.sportsName , 
                  batchName : request.batchId.batchName ,
                  coachName : request.batchId.coachName ,
                  startTime : request.batchId.startTime ,
                  endTime : request.batchId.endTime ,
                  fees : request.fees ,
                  enrolledId : request.enrolledId ,
                  enrolledStatus : request.enrolledStatus ,
                  paymentStatus : request.paymentStatus ,
                  timestamp :  request.enrolledTimeStamp ,
                  managerName : request.sportsId.managerId.userName
                }
        
                this.arrayObj.push(this.obj);
            }
    
            console.log(this.arrayObj);
    
          this.dataSource = new MatTableDataSource(this.arrayObj);
          console.log(this.dataSource);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.matSort;

      }
    )

  }

  filterData($event : any){
    console.log($event.target.value);
    this.dataSource.filter = $event.target.value;
    console.log(this.dataSource.filter);
  }
  
  
  exportTable(){
    TableUtil.exportToPdf("ExampleTable");
  }

}
