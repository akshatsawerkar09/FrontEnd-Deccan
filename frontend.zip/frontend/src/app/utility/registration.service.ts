import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IUser } from './IUser';

@Injectable({
  providedIn: 'root'
})
export class RegistrationService {

  baseUrl : string = "http://localhost:8080/admin";

  constructor(private _http :  HttpClient) { }

  addManager(manager : IUser) : Observable<IUser>{
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json'}) };
    return this._http.post<IUser>(this.baseUrl + '/addManager/',
    manager, httpOptions);
  }

  checkUsername(userName : string) : Observable<IUser>{
    return this._http.get<IUser>("http://localhost:8080/user" + '/checkUsername/'+ userName);
  }

  addUser(user : IUser) : Observable<IUser>{
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json'}) };
    return this._http.post<IUser>("http://localhost:8080/user" + '/registerUser/',
    user, httpOptions);
  }

  getAllManagers():Observable<IUser[]>{
    return this._http.get<IUser[]>(this.baseUrl + '/getAllManagers');
  }

  deleteManager(managerId : number){
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json'}) };
      return this._http.delete<number>(this.baseUrl + '/removeManager/' + managerId,
     httpOptions);
  }

  updateManager(manager : IUser):Observable<IUser>{
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json'}) };
    return this._http.put<IUser>(this.baseUrl + '/updateManager/',
    manager, httpOptions);
  }

  getManagerById(managerId : number):Observable<IUser>{
    return this._http.get<IUser>(this.baseUrl + '/getManagerById/' + managerId);
  }

}
