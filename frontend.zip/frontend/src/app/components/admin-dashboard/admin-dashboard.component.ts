import { Component, OnInit } from '@angular/core';
import { IUser } from 'src/app/utility/IUser';
import { NotificationService } from 'src/app/utility/notification.service';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.scss']
})
export class AdminDashboardComponent implements OnInit {

  user!: IUser;

  constructor(private _notificationService : NotificationService) { }

  ngOnInit(): void {
    this.user = JSON.parse(sessionStorage['user']);
    console.log(this.user);
    this._notificationService.sendNotification(this.user);
  }

}
