import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { IUser } from 'src/app/utility/IUser';
import { NotificationService } from 'src/app/utility/notification.service';
import { TableUtil } from 'src/app/utility/tableUtil';
import { UserService } from 'src/app/utility/user.service';

@Component({
  selector: 'app-unlock-accounts',
  templateUrl: './unlock-accounts.component.html',
  styleUrls: ['./unlock-accounts.component.scss']
})
export class UnlockAccountsComponent implements OnInit {

  constructor(private  _userService : UserService , private _notificationService : NotificationService) { }

  lockedAccounts!: IUser[];

  displayedColumns = ['userName','email' , 'gender' ,   'phoneNumber' , 'userRole', 'unlock' ];
  dataSource!: MatTableDataSource<any>;
    
  arrayObj : any [] = [];

  obj : any;

  user!: IUser;

  @ViewChild('paginator') paginator! : MatPaginator; 
  @ViewChild(MatSort) matSort! : MatSort;


  ngOnInit(): void {
    this.user = JSON.parse(sessionStorage['user']);
    console.log(this.user);
    this._notificationService.sendNotification(this.user);
    this.arrayObj = [];

    this._userService.getLockedAccounts().subscribe(
      data => {
        console.log(data);
        this.lockedAccounts = data;
        console.log(this.lockedAccounts);

        this.dataSource = new MatTableDataSource(this.lockedAccounts);
      console.log(this.dataSource);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.matSort;
      }
    )
  }

  unlockAccount(userId : number)
  {
    console.log(userId);
    this._userService.unlockAccount(userId).subscribe(
      data => {
        console.log(data);
      }
    )
    
    window.location.reload();
  }

  filterData($event : any){
    console.log($event.target.value);
    this.dataSource.filter = $event.target.value;
    console.log(this.dataSource.filter);
  }
  
  
  exportTable(){
    TableUtil.exportToPdf("ExampleTable");
  }
}
