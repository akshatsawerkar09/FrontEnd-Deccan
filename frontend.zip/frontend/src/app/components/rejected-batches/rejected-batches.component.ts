import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { EnrolledSportsService } from 'src/app/utility/enrolled-sports.service';
import { IEnrolledSports } from 'src/app/utility/IEnrolledSports';
import { IUser } from 'src/app/utility/IUser';
import { NotificationService } from 'src/app/utility/notification.service';
import { TableUtil } from 'src/app/utility/tableUtil';

@Component({
  selector: 'app-rejected-batches',
  templateUrl: './rejected-batches.component.html',
  styleUrls: ['./rejected-batches.component.scss']
})
export class RejectedBatchesComponent implements OnInit {

  user!: IUser;

  rejectedBatches!: IEnrolledSports[];

  constructor(private _enrollService : EnrolledSportsService , private _notificationService : NotificationService) {

   }

   displayedColumns = ['sportsName','batchName','coachName' , 'startTime' , 'endTime' ,  'managerName'];
  dataSource!: MatTableDataSource<any>;
    
  arrayObj : any [] = [];

  obj : any;

  @ViewChild('paginator') paginator! : MatPaginator; 
  @ViewChild(MatSort) matSort! : MatSort;

  ngOnInit(): void {
    this.user = JSON.parse(sessionStorage['user']);
    console.log(this.user);
    this._notificationService.sendNotification(this.user);
    this.arrayObj = [];

    this.user = JSON.parse(sessionStorage['user']);

    this._enrollService.getRejectedListByUser(this.user.userId).subscribe(
      data => {
        console.log(data);
        this.rejectedBatches = data;

        for(var batch of this.rejectedBatches)
        {
            this.obj= {
              sportsName : batch.sportsId.sportsName ,
              batchName : batch.batchId.batchName , 
              coachName : batch.batchId.coachName ,
              startTime : batch.batchId.startTime ,
              endTime : batch.batchId.endTime ,
              managerName :  batch.sportsId.managerId.userName ,
              enrolledId : batch.enrolledId
            }

            this.arrayObj.push(this.obj);
        }

        console.log(this.arrayObj);

        this.dataSource = new MatTableDataSource(this.arrayObj);
        console.log(this.dataSource);
        this.dataSource.paginator = this.paginator;
       this.dataSource.sort = this.matSort;
      }
    )
  }


  
filterData($event : any){
  console.log($event.target.value);
  this.dataSource.filter = $event.target.value;
  console.log(this.dataSource.filter);
}


exportTable(){
  TableUtil.exportToPdf("ExampleTable");
}

}
