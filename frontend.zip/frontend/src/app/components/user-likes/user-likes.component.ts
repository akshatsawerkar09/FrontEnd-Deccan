import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ILike } from 'src/app/utility/ILike';
import { IUser } from 'src/app/utility/IUser';
import { LikeService } from 'src/app/utility/like.service';
import { NotificationService } from 'src/app/utility/notification.service';
import { TableUtil } from 'src/app/utility/tableUtil';

@Component({
  selector: 'app-user-likes',
  templateUrl: './user-likes.component.html',
  styleUrls: ['./user-likes.component.scss']
})
export class UserLikesComponent implements OnInit {

  constructor(private _likeService : LikeService ,  private _notificationService :  NotificationService) { }

  user!: IUser;

  userLikes!: ILike[];

  displayedColumns = ['sportsName','sportsCategory' , 'batchName' , 'offer' ,  'discountOffered' , 'managerName' , 'timestamp'];
  dataSource!: MatTableDataSource<any>;
    
  arrayObj : any [] = [];

  obj : any;

  @ViewChild('paginator') paginator! : MatPaginator; 
  @ViewChild(MatSort) matSort! : MatSort;
  

  ngOnInit(): void {
    this.user = JSON.parse(sessionStorage['user']);
    console.log(this.user);
    this._notificationService.sendNotification(this.user);
    this.arrayObj = [];
    this.user = JSON.parse(sessionStorage['user']);

    this._likeService.getAllUserLikes(this.user.userId).subscribe(
      data => {
        console.log(data);
        this.userLikes = data;
        for(var like of this.userLikes)
        {
          console.log(like.timestamp);
            this.obj= {
              sportsName  : like.batchId.sportsId.sportsName ,
              sportsCategory : like.batchId.sportsId.sportsCategory ,
              batchName : like.batchId.batchName ,
              offer : like.batchId.offer ,
              discountOffered : like.batchId.discountOffered ,
              managerName : like.batchId.sportsId.managerId.userName,
              timestamp : like.timestamp
            }
    
            this.arrayObj.push(this.obj);
        }

        console.log(this.arrayObj);

      this.dataSource = new MatTableDataSource(this.arrayObj);
      console.log(this.dataSource);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.matSort;
      }
    )
  }

  filterData($event : any){
    console.log($event.target.value);
    this.dataSource.filter = $event.target.value;
    console.log(this.dataSource.filter);
  }
  
  
  exportTable(){
    TableUtil.exportToPdf("ExampleTable");
  }

}
