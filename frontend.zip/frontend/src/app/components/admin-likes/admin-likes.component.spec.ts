import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminLikesComponent } from './admin-likes.component';

describe('AdminLikesComponent', () => {
  let component: AdminLikesComponent;
  let fixture: ComponentFixture<AdminLikesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminLikesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminLikesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
