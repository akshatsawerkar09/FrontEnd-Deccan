import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { CommentService } from 'src/app/utility/comment.service';
import { ILike } from 'src/app/utility/ILike';
import { ISports } from 'src/app/utility/ISports';
import { IUser } from 'src/app/utility/IUser';
import { LikeService } from 'src/app/utility/like.service';
import { NotificationService } from 'src/app/utility/notification.service';
import { SportsService } from 'src/app/utility/sports.service';
import { TableUtil } from 'src/app/utility/tableUtil';

@Component({
  selector: 'app-manager-likes',
  templateUrl: './manager-likes.component.html',
  styleUrls: ['./manager-likes.component.scss']
})
export class ManagerLikesComponent implements OnInit {

  constructor(private _likeService : LikeService , private _sportsService : SportsService
    ,  private _notificationService : NotificationService) { }
  
  user!: IUser;

  managerLikes!: ILike[];

  displayedColumns = ['sportsName' , 'batchName' , 'offer' ,  'discountOffered' , 'managerName' , 'timestamp'];
  dataSource!: MatTableDataSource<any>;
    
  arrayObj : any [] = [];

  obj : any;
  sportsObj!: ISports;


  @ViewChild('paginator') paginator! : MatPaginator; 
  @ViewChild(MatSort) matSort! : MatSort;

  ngOnInit(): void {
    this.user = JSON.parse(sessionStorage['user']);
    console.log(this.user);
    this._notificationService.sendNotification(this.user);
    this.arrayObj = [];
    this.user = JSON.parse(sessionStorage['user']);

    this._sportsService.getSportsByManagerId(this.user.userId).subscribe(
      data => {
        console.log(data);
        this.sportsObj = data;
        this._likeService.getAllSportsLikes(this.sportsObj.sportsId).subscribe(
          data => {
            console.log(data);
            this.managerLikes = data;
            for(var like of this.managerLikes)
            {
            this.obj= {
              sportsName  : like.batchId.sportsId.sportsName ,
              userName : like.userId.userName ,
              batchName : like.batchId.batchName ,
              offer : like.batchId.offer ,
              discountOffered : like.batchId.discountOffered ,
              managerName :  like.batchId.sportsId.managerId.userName ,
              timestamp : like.timestamp
             // managerName : like.batchId.sportsId.managerId.userName 
            }
    
            this.arrayObj.push(this.obj);
          }

        console.log(this.arrayObj);

        this.dataSource = new MatTableDataSource(this.arrayObj);
        console.log(this.dataSource);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.matSort;
          }
        )
      }
    )
  }

  filterData($event : any){
    console.log($event.target.value);
    this.dataSource.filter = $event.target.value;
    console.log(this.dataSource.filter);
  }
  
  
  exportTable(){
    TableUtil.exportToPdf("ExampleTable");
  }

}
