export interface IUser{
    userId : number;
    address : string;
    email : string;
    gender : string;
    loginAttempt : number;
    password : string;
    phoneNumber : string;
    userName : string;
    userRole : string;
    otp : number;
    activateStatus : boolean;
}