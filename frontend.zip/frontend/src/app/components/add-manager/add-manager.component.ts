import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { IUser } from 'src/app/utility/IUser';
import { NotificationService } from 'src/app/utility/notification.service';
import { RegistrationService } from 'src/app/utility/registration.service';
import { TableUtil } from 'src/app/utility/tableUtil';

@Component({
  selector: 'app-add-manager',
  templateUrl: './add-manager.component.html',
  styleUrls: ['./add-manager.component.scss']
})
export class AddManagerComponent implements OnInit {

  managerList!: IUser[];

  user!: IUser;

  constructor(private _registrationService  :  RegistrationService , private _router : Router ,
    private _notificationService : NotificationService) { }

  displayedColumns = ['userName','email','password' , 'phoneNumber' , 'address' , 'gender' ,  'update' , 'delete'];
  dataSource!: MatTableDataSource<any>;

  @ViewChild('paginator') paginator! : MatPaginator; 
  @ViewChild(MatSort) matSort! : MatSort;

  ngOnInit(): void {
    this.user = JSON.parse(sessionStorage['user']);
    console.log(this.user);
   // this._notificationService.sendNotification(this.user);

    this._registrationService.getAllManagers().subscribe(
      data => {
        console.log(data);
        this.managerList = data;
        this.dataSource = new MatTableDataSource(this.managerList);
      console.log(this.dataSource);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.matSort;
      }
    )
    
  }

  

  addManagerObj!: IUser;

  usernameNotAvailable : string = "";

  managerForm= new FormGroup({
    userName : new FormControl('',[Validators.required]),
    userRole : new FormControl('',[Validators.required]),
    email : new FormControl('',[Validators.required]),
    password : new FormControl('',Validators.required),
    phoneNumber : new FormControl('',Validators.required),
    gender : new FormControl('MALE',Validators.required),
    address : new FormControl('',Validators.required),
    loginAttempt : new FormControl('',Validators.required),
    otp : new FormControl('',Validators.required),
    activateStatus : new FormControl('',Validators.required)
  });
  
  addManager(managerForm  : FormGroup)
  {
      this.addManagerObj = this.managerForm.value;
      this.addManagerObj.userRole = "MANAGER";
      this.addManagerObj.loginAttempt = 0;
      this.addManagerObj.otp  = 0;
      this.addManagerObj.activateStatus = false;
      console.log(this.addManagerObj);

      this._registrationService.checkUsername(this.addManagerObj.userName).subscribe(
        data =>  {
          console.log(data);
          if(data  == null)
          {
            this.usernameNotAvailable =  "";
            this._registrationService.addManager(this.addManagerObj).subscribe(
              data => {
                console.log(data);
                window.location.reload();
              }
            )
          }
          else
          {
             this.usernameNotAvailable =  "show now";
          }
        }
      )
      
    
  }


  updateManager(id : number)
  {
    this._router.navigate(['/updateManager/'+id]);
  }

  deleteManager(managerId : number)
  {
    console.log(managerId);
    this._registrationService.deleteManager(managerId).subscribe(
      data => {
        console.log(data);
       
      } ,
      error => {
       
      }
      
    )
    window.location.reload();
  }

  filterData($event : any){
    console.log($event.target.value);
    this.dataSource.filter = $event.target.value;
    console.log(this.dataSource.filter);
  }
  
  
  exportTable(){
    TableUtil.exportToPdf("ExampleTable");
  }
}
