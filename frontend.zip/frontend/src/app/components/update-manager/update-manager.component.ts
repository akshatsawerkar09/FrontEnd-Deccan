import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { IUser } from 'src/app/utility/IUser';
import { NotificationService } from 'src/app/utility/notification.service';
import { RegistrationService } from 'src/app/utility/registration.service';

@Component({
  selector: 'app-update-manager',
  templateUrl: './update-manager.component.html',
  styleUrls: ['./update-manager.component.scss']
})
export class UpdateManagerComponent implements OnInit {

  managerId!: number;

  manager!: IUser;

  user!: IUser;

  usernameNotAvailable : string = "";

  constructor(private _activatedRoute : ActivatedRoute , private _registrationService  : RegistrationService
    , private _router : Router , private _notificationService  : NotificationService) { }

  managerForm!: FormGroup;
  
  ngOnInit(): void {

    this.user = JSON.parse(sessionStorage['user']);
    console.log(this.user);
    this._notificationService.sendNotification(this.user);

    this.managerForm= new FormGroup({
      userName : new FormControl('',[Validators.required]),
      userRole : new FormControl('',[Validators.required]),
      email : new FormControl('',[Validators.required]),
      password : new FormControl('',Validators.required),
      phoneNumber : new FormControl('',Validators.required),
      gender : new FormControl('MALE',Validators.required),
      address : new FormControl('',Validators.required),
      loginAttempt : new FormControl('',Validators.required),
      otp : new FormControl('',Validators.required),
      activateStatus : new FormControl('',Validators.required)
    });

    this._activatedRoute.params.subscribe( p => { this.managerId = p.id ;})

    this._registrationService.getManagerById(this.managerId).subscribe(
      data => {
        console.log(data);
        this.manager = data;
        this.managerForm= new FormGroup({
          userName : new FormControl(this.manager.userName,[Validators.required]),
          userRole : new FormControl(this.manager.userRole,[Validators.required]),
          email : new FormControl(this.manager.email,[Validators.required]),
          password : new FormControl(this.manager.password,Validators.required),
          phoneNumber : new FormControl(this.manager.phoneNumber,Validators.required),
          gender : new FormControl(this.manager.gender,Validators.required),
          address : new FormControl(this.manager.address,Validators.required),
        });
      }
    )
  }



  updateManager(managerForm : FormGroup)
  {
      this.manager = this.managerForm.value;
      this.manager.userId = this.managerId;
      console.log(this.manager);
      this._registrationService.updateManager(this.manager).subscribe(
        data => {
          console.log(data);
        }
      )
     this._router.navigate(['/addManager']);
  }

}
