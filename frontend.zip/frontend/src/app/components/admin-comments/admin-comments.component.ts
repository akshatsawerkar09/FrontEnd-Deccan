import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { CommentService } from 'src/app/utility/comment.service';
import { IComment } from 'src/app/utility/IComment';
import { ISports } from 'src/app/utility/ISports';
import { IUser } from 'src/app/utility/IUser';
import { NotificationService } from 'src/app/utility/notification.service';
import { TableUtil } from 'src/app/utility/tableUtil';

@Component({
  selector: 'app-admin-comments',
  templateUrl: './admin-comments.component.html',
  styleUrls: ['./admin-comments.component.scss']
})
export class AdminCommentsComponent implements OnInit {

  user!: IUser;

  userComments!: IComment[];

  displayedColumns = ['sportsName', 'userName' , 'batchName' , 'offer' ,  'discountOffered' , 'comment' , 'timestamp'];
  dataSource!: MatTableDataSource<any>;
    
  arrayObj : any [] = [];

  sportsObj!: ISports;

  obj : any;

  @ViewChild('paginator') paginator! : MatPaginator; 
  @ViewChild(MatSort) matSort! : MatSort;

  constructor(private _commentService : CommentService , private _notificationService : NotificationService) { }

  ngOnInit(): void {
    this.user = JSON.parse(sessionStorage['user']);
    console.log(this.user);
    this._notificationService.sendNotification(this.user);


    this.arrayObj = [];
    this.user = JSON.parse(sessionStorage['user']);
    this._commentService.getAllComments().subscribe(
      data => {
        console.log(data);
        this.userComments = data;
        for(var comment of this.userComments)
        {
        this.obj= {
          sportsName  : comment.batchId.sportsId.sportsName ,
          userName : comment.userId.userName ,
          batchName : comment.batchId.batchName ,
          offer : comment.batchId.offer ,
          discountOffered : comment.batchId.discountOffered ,
          comment : comment.comment ,
          timestamp : comment.timestamp
         // managerName : like.batchId.sportsId.managerId.userName 
        }

        this.arrayObj.push(this.obj);
      }

    console.log(this.arrayObj);

    this.dataSource = new MatTableDataSource(this.arrayObj);
    console.log(this.dataSource);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.matSort;

      }
    )

  }

  filterData($event : any){
    console.log($event.target.value);
    this.dataSource.filter = $event.target.value;
    console.log(this.dataSource.filter);
  }
  
  
  exportTable(){
    TableUtil.exportToPdf("ExampleTable");
  }


}
