import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { CommentService } from 'src/app/utility/comment.service';
import { IComment } from 'src/app/utility/IComment';
import { ISports } from 'src/app/utility/ISports';
import { IUser } from 'src/app/utility/IUser';
import { NotificationService } from 'src/app/utility/notification.service';
import { SportsService } from 'src/app/utility/sports.service';
import { TableUtil } from 'src/app/utility/tableUtil';

@Component({
  selector: 'app-manager-comments',
  templateUrl: './manager-comments.component.html',
  styleUrls: ['./manager-comments.component.scss']
})
export class ManagerCommentsComponent implements OnInit {

  constructor(private _commentService : CommentService , private _sportsService : SportsService
    , private _notificationService  : NotificationService) { }

  user!: IUser;

  userComments!: IComment[];

  displayedColumns = ['sportsName', 'userName' , 'batchName' , 'offer' ,  'discountOffered' , 'comment' , 'timestamp'];
  dataSource!: MatTableDataSource<any>;
    
  arrayObj : any [] = [];

  sportsObj!: ISports;

  obj : any;

  @ViewChild('paginator') paginator! : MatPaginator; 
  @ViewChild(MatSort) matSort! : MatSort;

  ngOnInit(): void {
    this.user = JSON.parse(sessionStorage['user']);
    console.log(this.user);
    this._notificationService.sendNotification(this.user);
    this.arrayObj = [];
    this.user = JSON.parse(sessionStorage['user']);
    this._sportsService.getSportsByManagerId(this.user.userId).subscribe(
      data => {
        console.log(data);
        this.sportsObj = data;
        this._commentService.getAllSportsComments(this.sportsObj.sportsId).subscribe(
          data => {
            console.log(data);
            this.userComments = data;

            for(var comment of this.userComments)
            {
            this.obj= {
              sportsName  : comment.batchId.sportsId.sportsName ,
              userName : comment.userId.userName ,
              batchName : comment.batchId.batchName ,
              offer : comment.batchId.offer ,
              discountOffered : comment.batchId.discountOffered ,
              comment : comment.comment ,
              timestamp : comment.timestamp
             // managerName : like.batchId.sportsId.managerId.userName 
            }
    
            this.arrayObj.push(this.obj);
          }

        console.log(this.arrayObj);

        this.dataSource = new MatTableDataSource(this.arrayObj);
        console.log(this.dataSource);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.matSort;
          }
        )
      }
    )

  }

  filterData($event : any){
    console.log($event.target.value);
    this.dataSource.filter = $event.target.value;
    console.log(this.dataSource.filter);
  }
  
  
  exportTable(){
    TableUtil.exportToPdf("ExampleTable");
  }

}
