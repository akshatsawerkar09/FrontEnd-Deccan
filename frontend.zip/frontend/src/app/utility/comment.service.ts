import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IComment } from './IComment';
import { ILike } from './ILike';

@Injectable({
  providedIn: 'root'
})
export class CommentService {

  constructor(private _http :  HttpClient) { }

  baseUrl : string = "http://localhost:8080/user";

  getAllComments() : Observable<IComment[]>{
    return this._http.get<IComment[]>(this.baseUrl + '/getAllComments');
  }

  addComment(comment : IComment) : Observable<IComment>{
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json'}) };
    return this._http.post<IComment>(this.baseUrl + '/addComment/',
    comment, httpOptions);
  }

  getAllUserComments(userId : number) : Observable<IComment[]>{
    return this._http.get<IComment[]>(this.baseUrl + '/getAllUserComments/' + userId);
  }

  getAllSportsComments(userId : number) : Observable<IComment[]>{
    return this._http.get<IComment[]>("http://localhost:8080/manager" + '/getAllSportsComments/' + userId);
  }
}
