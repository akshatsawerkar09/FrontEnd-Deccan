import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagerLikesComponent } from './manager-likes.component';

describe('ManagerLikesComponent', () => {
  let component: ManagerLikesComponent;
  let fixture: ComponentFixture<ManagerLikesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManagerLikesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagerLikesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
