import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { IUser } from './IUser';

@Injectable({
  providedIn: 'root'
})
export class NotificationService {

  private subject = new Subject<any>();

  constructor() { }

  sendNotification(user : IUser)
  {
    this.subject.next(user);
  }
  
  getNotification():Observable<IUser>
  {
    return this.subject.asObservable();
  }

  

}
