import {AfterViewInit, Component, OnInit, ViewChild} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import { EnrolledSportsService } from 'src/app/utility/enrolled-sports.service';
import { IEnrolledSports } from 'src/app/utility/IEnrolledSports';
import { IUser } from 'src/app/utility/IUser';
import { NotificationService } from 'src/app/utility/notification.service';
import { TableUtil } from 'src/app/utility/tableUtil';


@Component({
  selector: 'app-applied-batches',
  templateUrl: './applied-batches.component.html',
  styleUrls: ['./applied-batches.component.scss']
})
export class AppliedBatchesComponent implements OnInit {

  user!: IUser;

  appliedBatches!: IEnrolledSports[];

  arrayObj : any [] = [];

  obj : any;

  displayedColumns = ['sportsName','batchName','coachName' , 'startTime' , 'endTime' ,  'managerName'];
  dataSource!: MatTableDataSource<any>;

  @ViewChild('paginator') paginator! : MatPaginator; 
  @ViewChild(MatSort) matSort! : MatSort;

  constructor(private _enrollService : EnrolledSportsService , private _notificationService : NotificationService)
  {
      
  }

  ngOnInit(): void {
    this.user = JSON.parse(sessionStorage['user']);
    console.log(this.user);
    this._notificationService.sendNotification(this.user);
    this.arrayObj = [];
    this.user = JSON.parse(sessionStorage['user']);

    this._enrollService.getAppliedListByUser(this.user.userId).subscribe(
      data => {
        console.log(data);
        this.appliedBatches = data;

        for(var batch of this.appliedBatches)
          {
              this.obj= {
                sportsName : batch.sportsId.sportsName ,
                batchName : batch.batchId.batchName , 
                coachName : batch.batchId.coachName ,
                startTime : batch.batchId.startTime ,
                endTime : batch.batchId.endTime ,
                managerName :  batch.sportsId.managerId.userName 
              }

              this.arrayObj.push(this.obj);
          }

          console.log(this.arrayObj);

          this.dataSource = new MatTableDataSource(this.arrayObj);
          console.log(this.dataSource);
          this.dataSource.paginator = this.paginator;
         this.dataSource.sort = this.matSort;
      }
    )
  }

  
  filterData($event : any){
    console.log($event.target.value);
    this.dataSource.filter = $event.target.value;
    console.log(this.dataSource.filter);
  }
  
  
  exportTable(){
    TableUtil.exportToPdf("ExampleTable");
  }
  

}

