import { HttpClient } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { ISports } from 'src/app/utility/ISports';
import { IUser } from 'src/app/utility/IUser';
import { NotificationService } from 'src/app/utility/notification.service';
import { SportsService } from 'src/app/utility/sports.service';
import { TableUtil } from 'src/app/utility/tableUtil';

@Component({
  selector: 'app-manage-sports',
  templateUrl: './manage-sports.component.html',
  styleUrls: ['./manage-sports.component.scss']
})
export class ManageSportsComponent implements OnInit {

  constructor(private _http :  HttpClient , private _sportsService : SportsService , private _router : Router
    , private _notificationService  :  NotificationService) { }

  baseUrl : string = "http://localhost:8080/manager";

  managers!: IUser[];

  sports !: ISports[];

  sportsForm : any;

  initialData : number = 0;

  displayedColumns = ['sportsName','sportsCategory','membersCharge' , 'nonMembersCharge' , 'managerName' ,  'update' , 'delete'];
  dataSource!: MatTableDataSource<any>;
    
  arrayObj : any [] = [];

  obj : any;

  user!: IUser;

  @ViewChild('paginator') paginator! : MatPaginator; 
  @ViewChild(MatSort) matSort! : MatSort;

  ngOnInit(): void {
    this.arrayObj = [];
    this.user = JSON.parse(sessionStorage['user']);
    console.log(this.user);
    //this._notificationService.sendNotification(this.user);
    

    this.sportsForm= new FormGroup({
      sportsName : new FormControl('',[Validators.required]),
      sportsCategory : new FormControl('INDOOR',[Validators.required]),
      managerId : new FormControl('',[Validators.required]),
      membersCharge : new FormControl('',Validators.required),
      nonMembersCharge : new FormControl('',Validators.required)
    });
    
    this._sportsService.getIdelManagerList().subscribe(
      data => {
        console.log(data);
        this.managers = data;
        console.log(this.managers);
        if(this.managers.length !== 0)
        {
            this.initialData = this.managers[0].userId;
        }
        this.sportsForm= new FormGroup({
          sportsName : new FormControl('',[Validators.required]),
          sportsCategory : new FormControl('INDOOR',[Validators.required]),
          managerId : new FormControl(this.initialData,[Validators.required]),
          membersCharge : new FormControl('',Validators.required),
          nonMembersCharge : new FormControl('',Validators.required)
        });
      }
    )

   
    this._sportsService.getAllSports().subscribe(
      data => {
        console.log(data);
        this.sports = data;
        console.log(this.sports);
        for(var sport of this.sports)
        {
            this.obj= {
              sportsName : sport.sportsName ,
              sportsCategory : sport.sportsCategory , 
              membersCharge : sport.membersCharge ,
              nonMembersCharge : sport.nonMembersCharge ,
              managerName : sport.managerId.userName,
              sportsId : sport.sportsId
            }
    
            this.arrayObj.push(this.obj);
        }

        console.log(this.arrayObj);

      this.dataSource = new MatTableDataSource(this.arrayObj);
      console.log(this.dataSource);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.matSort;
    
      }
    )
  }

  

  sportsObj!: ISports ;

  manager!: IUser;

  temp!: number | undefined | null;

  seletedManager!: any;

  
  

  addSports(sportsForm : FormGroup)
  {

      this.temp = this.sportsForm.controls['managerId'].value;

      
    console.log(this.temp);
     // console.log(this.sportsForm.controls['managerId'].value.managerId);

  

      console.log(this.managers);

      this.seletedManager =  this.managers.find(e => e.userId == this.temp);

      console.log(this.seletedManager);

      console.log(this.sportsForm);

      this.sportsObj = this.sportsForm.value;

      this.sportsObj.managerId = this.seletedManager; 

      console.log(this.sportsObj);

      this._sportsService.addSports(this.sportsObj).subscribe(
        data => {
          console.log(this.sportsObj);
          console.log("sports added");
         // window.location.reload();
         this.ngOnInit();
        }
      )

    // window.location.reload();
     //this.ngOnInit();
  }


  deleteSports(id : number)
  {
    this._sportsService.deleteSports(id).subscribe(
      data => {
        console.log(this.sportsObj);
        console.log("sports deleted");
      } , 
      error => {
        //window.location.reload();
        this.ngOnInit();
      }
    )    
  // window.location.reload();
   //this.ngOnInit();  
   
  }

  updateSports(id : number)
  {
    this._router.navigate(['/updateSports/'+id]);
  }
  
  filterData($event : any){
    console.log($event.target.value);
    this.dataSource.filter = $event.target.value;
    console.log(this.dataSource.filter);
  }
  
  
  exportTable(){
    TableUtil.exportToPdf("ExampleTable");
  }
}
