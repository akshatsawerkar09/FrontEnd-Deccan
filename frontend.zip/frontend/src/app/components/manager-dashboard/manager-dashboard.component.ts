import { Component, OnInit } from '@angular/core';
import { IUser } from 'src/app/utility/IUser';
import { NotificationService } from 'src/app/utility/notification.service';

@Component({
  selector: 'app-manager-dashboard',
  templateUrl: './manager-dashboard.component.html',
  styleUrls: ['./manager-dashboard.component.scss']
})
export class ManagerDashboardComponent implements OnInit {

  constructor(private _notificationService  : NotificationService) { }

  user!: IUser;

  ngOnInit(): void {
    this.user = JSON.parse(sessionStorage['user']);
    console.log(this.user);
    this._notificationService.sendNotification(this.user);
  }

}
